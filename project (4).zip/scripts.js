$(document).ready(function() {
$('#search').hideseek({
attribute: 'data-title'
});
});